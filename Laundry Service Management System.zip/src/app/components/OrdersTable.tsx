import React from 'react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Order, OrderStatus } from '../context/AppContext';
import { formatDistanceToNow } from 'date-fns';

interface OrdersTableProps {
  orders: Order[];
  showAll?: boolean;
  onOrderClick?: (order: Order) => void;
}

const OrdersTable: React.FC<OrdersTableProps> = ({ orders, showAll = false, onOrderClick }) => {
  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case 'requested': return 'bg-yellow-100 text-yellow-800';
      case 'picked_up': return 'bg-blue-100 text-blue-800';
      case 'received': return 'bg-indigo-100 text-indigo-800';
      case 'washing': return 'bg-purple-100 text-purple-800';
      case 'ironing': return 'bg-pink-100 text-pink-800';
      case 'ready': return 'bg-green-100 text-green-800';
      case 'out_for_delivery': return 'bg-orange-100 text-orange-800';
      case 'delivered': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusLabel = (status: OrderStatus) => {
    return status.split('_').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  const getServiceTypeLabel = (serviceType: string) => {
    switch (serviceType) {
      case 'wash': return 'Wash Only';
      case 'wash_iron': return 'Wash & Iron';
      case 'dry_clean': return 'Dry Clean';
      default: return serviceType;
    }
  };

  if (orders.length === 0) {
    return null;
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead className="bg-gray-50 border-b">
          <tr>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Order ID
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Customer
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Service
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Status
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Total
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Created
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {orders.map((order) => (
            <tr key={order.id} className="hover:bg-gray-50">
              <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                #{order.id.slice(-6).toUpperCase()}
              </td>
              <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">
                {order.customerName}
              </td>
              <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">
                {getServiceTypeLabel(order.serviceType)}
              </td>
              <td className="px-4 py-4 whitespace-nowrap">
                <Badge className={getStatusColor(order.status)}>
                  {getStatusLabel(order.status)}
                </Badge>
              </td>
              <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                ${order.total.toFixed(2)}
              </td>
              <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                {formatDistanceToNow(new Date(order.createdAt), { addSuffix: true })}
              </td>
              <td className="px-4 py-4 whitespace-nowrap text-sm">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onOrderClick?.(order)}
                >
                  View Details
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default OrdersTable;
