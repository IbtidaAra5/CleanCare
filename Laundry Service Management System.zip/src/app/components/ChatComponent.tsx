import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Send } from 'lucide-react';
import { format } from 'date-fns';

interface ChatComponentProps {
  orderId: string;
}

const ChatComponent: React.FC<ChatComponentProps> = ({ orderId }) => {
  const { currentUser, sendMessage, getOrderMessages } = useApp();
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState(getOrderMessages(orderId));
  const scrollRef = useRef<HTMLDivElement>(null);

  // Poll for new messages (in a real app, use websockets)
  useEffect(() => {
    const interval = setInterval(() => {
      setMessages(getOrderMessages(orderId));
    }, 2000);

    return () => clearInterval(interval);
  }, [orderId, getOrderMessages]);

  useEffect(() => {
    // Scroll to bottom when new messages arrive
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!message.trim() || !currentUser) return;

    sendMessage({
      orderId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderRole: currentUser.role,
      message: message.trim()
    });

    setMessage('');
    setTimeout(() => {
      setMessages(getOrderMessages(orderId));
    }, 100);
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-purple-500';
      case 'staff': return 'bg-blue-500';
      case 'delivery': return 'bg-orange-500';
      case 'customer': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="flex flex-col h-[400px]">
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        {messages.length === 0 ? (
          <div className="text-center text-gray-500 py-8">
            No messages yet. Start the conversation!
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((msg) => {
              const isMe = msg.senderId === currentUser?.id;
              
              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 ${isMe ? 'flex-row-reverse' : 'flex-row'}`}
                >
                  <Avatar className="w-8 h-8">
                    <AvatarFallback className={getRoleColor(msg.senderRole)}>
                      {getInitials(msg.senderName)}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} max-w-[70%]`}>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-medium">{msg.senderName}</span>
                      <span className="text-xs text-gray-400">
                        {format(new Date(msg.timestamp), 'p')}
                      </span>
                    </div>
                    
                    <div
                      className={`rounded-lg px-4 py-2 ${
                        isMe
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-100 text-gray-900'
                      }`}
                    >
                      <p className="text-sm">{msg.message}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </ScrollArea>

      <form onSubmit={handleSend} className="p-4 border-t flex gap-2">
        <Input
          placeholder="Type your message..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          className="flex-1"
        />
        <Button type="submit" disabled={!message.trim()}>
          <Send className="w-4 h-4" />
        </Button>
      </form>
    </div>
  );
};

export default ChatComponent;
