import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

interface CreateOrderModalProps {
  onClose: () => void;
}

const CreateOrderModal: React.FC<CreateOrderModalProps> = ({ onClose }) => {
  const { currentUser, stores, createOrder } = useApp();
  
  const [formData, setFormData] = useState({
    storeId: '',
    serviceType: 'wash_iron' as 'wash' | 'wash_iron' | 'dry_clean',
    pickupAddress: currentUser?.address || '',
    pickupDate: new Date(),
    pickupTime: '10:00',
    notes: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.storeId || !formData.pickupAddress) {
      toast.error('Please fill all required fields');
      return;
    }

    const store = stores.find(s => s.id === formData.storeId);
    if (!store) return;

    // Combine date and time
    const pickupDateTime = new Date(formData.pickupDate);
    const [hours, minutes] = formData.pickupTime.split(':');
    pickupDateTime.setHours(parseInt(hours), parseInt(minutes));

    const orderId = createOrder({
      customerId: currentUser!.id,
      customerName: currentUser!.name,
      storeId: store.id,
      storeName: store.name,
      status: 'requested',
      serviceType: formData.serviceType,
      pickupAddress: formData.pickupAddress,
      pickupTime: pickupDateTime.toISOString(),
      items: [], // Items will be added by staff
      total: 0,
      paid: false
    });

    toast.success('Order created successfully!');
    onClose();
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New Order</DialogTitle>
          <DialogDescription>
            Request a pickup for your laundry
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="store">Select Store *</Label>
            <Select
              value={formData.storeId}
              onValueChange={(value) => setFormData({ ...formData, storeId: value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Choose a store" />
              </SelectTrigger>
              <SelectContent>
                {stores.map(store => (
                  <SelectItem key={store.id} value={store.id}>
                    <div className="flex flex-col">
                      <span>{store.name}</span>
                      <span className="text-xs text-gray-500">{store.address}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="service">Service Type *</Label>
            <Select
              value={formData.serviceType}
              onValueChange={(value: any) => setFormData({ ...formData, serviceType: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="wash">Wash Only</SelectItem>
                <SelectItem value="wash_iron">Wash & Iron</SelectItem>
                <SelectItem value="dry_clean">Dry Clean</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">Pickup Address *</Label>
            <Textarea
              id="address"
              placeholder="123 Main St, Apt 4B"
              value={formData.pickupAddress}
              onChange={(e) => setFormData({ ...formData, pickupAddress: e.target.value })}
              rows={2}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Pickup Date *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(formData.pickupDate, 'PPP')}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={formData.pickupDate}
                    onSelect={(date) => date && setFormData({ ...formData, pickupDate: date })}
                    disabled={(date) => date < new Date()}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label htmlFor="time">Pickup Time *</Label>
              <Input
                id="time"
                type="time"
                value={formData.pickupTime}
                onChange={(e) => setFormData({ ...formData, pickupTime: e.target.value })}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Special Instructions (Optional)</Label>
            <Textarea
              id="notes"
              placeholder="Any special requests or instructions..."
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              rows={3}
            />
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-sm text-gray-700">
              <strong>Note:</strong> Item details and pricing will be confirmed by our staff after pickup. 
              You'll be notified once the total cost is calculated.
            </p>
          </div>

          <div className="flex gap-3">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button type="submit" className="flex-1">
              Create Order
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default CreateOrderModal;
