import React, { useState } from 'react';
import { useApp, Order, OrderStatus, OrderItem, UserRole } from '../context/AppContext';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Textarea } from './ui/textarea';
import { MapPin, Calendar, Package, DollarSign, Star, MessageSquare, Download, Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import jsPDF from 'jspdf';
import ChatComponent from './ChatComponent';

interface OrderDetailsModalProps {
  order: Order;
  onClose: () => void;
  userRole: UserRole;
}

const OrderDetailsModal: React.FC<OrderDetailsModalProps> = ({ order, onClose, userRole }) => {
  const { updateOrderStatus, updateOrderItems, assignDelivery, rateOrder, payOrder, users, stores } = useApp();
  
  const [items, setItems] = useState<OrderItem[]>(order.items);
  const [newItem, setNewItem] = useState({ type: '', quantity: 1, price: 0 });
  const [selectedDelivery, setSelectedDelivery] = useState(order.deliveryPersonId || '');
  const [rating, setRating] = useState(order.rating || 0);
  const [feedback, setFeedback] = useState(order.feedback || '');
  const [paymentMethod, setPaymentMethod] = useState('online');

  const deliveryPersons = users.filter(u => u.role === 'delivery');
  const store = stores.find(s => s.id === order.storeId);

  const statusFlow: OrderStatus[] = [
    'requested', 'picked_up', 'received', 'washing', 'ironing', 'ready', 'out_for_delivery', 'delivered'
  ];

  const canUpdateStatus = (targetStatus: OrderStatus) => {
    const currentIndex = statusFlow.indexOf(order.status);
    const targetIndex = statusFlow.indexOf(targetStatus);
    return targetIndex === currentIndex + 1;
  };

  const handleStatusUpdate = (newStatus: OrderStatus) => {
    updateOrderStatus(order.id, newStatus);
    toast.success(`Order status updated to ${newStatus.replace('_', ' ')}`);
  };

  const handleAddItem = () => {
    if (!newItem.type || newItem.quantity <= 0 || newItem.price <= 0) {
      toast.error('Please fill all item details');
      return;
    }

    const updatedItems = [
      ...items,
      { ...newItem, id: `item_${Date.now()}` }
    ];
    setItems(updatedItems);
    updateOrderItems(order.id, updatedItems);
    setNewItem({ type: '', quantity: 1, price: 0 });
    toast.success('Item added');
  };

  const handleRemoveItem = (itemId: string) => {
    const updatedItems = items.filter(i => i.id !== itemId);
    setItems(updatedItems);
    updateOrderItems(order.id, updatedItems);
    toast.success('Item removed');
  };

  const handleAssignDelivery = () => {
    if (!selectedDelivery) {
      toast.error('Please select a delivery person');
      return;
    }
    const person = deliveryPersons.find(d => d.id === selectedDelivery);
    if (person) {
      assignDelivery(order.id, person.id, person.name);
      toast.success('Delivery person assigned');
    }
  };

  const handleRating = () => {
    if (rating === 0) {
      toast.error('Please select a rating');
      return;
    }
    rateOrder(order.id, rating, feedback);
    toast.success('Thank you for your feedback!');
  };

  const handlePayment = () => {
    payOrder(order.id, paymentMethod);
    toast.success('Payment successful!');
  };

  const generatePDF = () => {
    const doc = new jsPDF();
    
    // Header
    doc.setFontSize(20);
    doc.text('CleanCare Laundry Service', 20, 20);
    doc.setFontSize(12);
    doc.text('Invoice', 20, 30);
    
    // Order Details
    doc.setFontSize(10);
    doc.text(`Order ID: #${order.id.slice(-8).toUpperCase()}`, 20, 45);
    doc.text(`Date: ${format(new Date(order.createdAt), 'PPP')}`, 20, 52);
    doc.text(`Customer: ${order.customerName}`, 20, 59);
    doc.text(`Store: ${order.storeName}`, 20, 66);
    
    // Items
    doc.text('Items:', 20, 80);
    let yPos = 90;
    items.forEach((item, idx) => {
      doc.text(
        `${idx + 1}. ${item.type} x${item.quantity} @ $${item.price} = $${(item.quantity * item.price).toFixed(2)}`,
        25,
        yPos
      );
      yPos += 7;
    });
    
    // Total
    yPos += 10;
    doc.setFontSize(12);
    doc.text(`Total: $${order.total.toFixed(2)}`, 20, yPos);
    doc.text(`Payment Status: ${order.paid ? 'Paid' : 'Pending'}`, 20, yPos + 10);
    
    // Footer
    doc.setFontSize(8);
    doc.text('Thank you for choosing CleanCare!', 20, 280);
    
    doc.save(`invoice-${order.id}.pdf`);
    toast.success('Invoice downloaded');
  };

  const getStatusColor = (status: OrderStatus) => {
    switch (status) {
      case 'requested': return 'bg-yellow-100 text-yellow-800';
      case 'picked_up': return 'bg-blue-100 text-blue-800';
      case 'received': return 'bg-indigo-100 text-indigo-800';
      case 'washing': return 'bg-purple-100 text-purple-800';
      case 'ironing': return 'bg-pink-100 text-pink-800';
      case 'ready': return 'bg-green-100 text-green-800';
      case 'out_for_delivery': return 'bg-orange-100 text-orange-800';
      case 'delivered': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle>Order #{order.id.slice(-8).toUpperCase()}</DialogTitle>
              <DialogDescription>
                Created {format(new Date(order.createdAt), 'PPP')}
              </DialogDescription>
            </div>
            <Badge className={getStatusColor(order.status)}>
              {order.status.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
            </Badge>
          </div>
        </DialogHeader>

        <Tabs defaultValue="details" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="details">Details</TabsTrigger>
            <TabsTrigger value="status">Status</TabsTrigger>
            <TabsTrigger value="payment">Payment</TabsTrigger>
            <TabsTrigger value="chat">Chat</TabsTrigger>
          </TabsList>

          <TabsContent value="details" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-gray-400 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Pickup Address</p>
                    <p className="text-sm text-gray-600">{order.pickupAddress}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Calendar className="w-5 h-5 text-gray-400 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Pickup Time</p>
                    <p className="text-sm text-gray-600">
                      {format(new Date(order.pickupTime), 'PPP p')}
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Package className="w-5 h-5 text-gray-400 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Service Type</p>
                    <p className="text-sm text-gray-600">
                      {order.serviceType.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Package className="w-5 h-5 text-gray-400 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Store</p>
                    <p className="text-sm text-gray-600">{order.storeName}</p>
                  </div>
                </div>
                {order.deliveryPersonName && (
                  <div className="flex items-start gap-3">
                    <Package className="w-5 h-5 text-gray-400 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium">Delivery Person</p>
                      <p className="text-sm text-gray-600">{order.deliveryPersonName}</p>
                    </div>
                  </div>
                )}
                <div className="flex items-start gap-3">
                  <DollarSign className="w-5 h-5 text-gray-400 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium">Payment Status</p>
                    <Badge variant={order.paid ? 'default' : 'secondary'}>
                      {order.paid ? 'Paid' : 'Pending'}
                    </Badge>
                  </div>
                </div>
              </div>
            </div>

            <Separator />

            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold">Order Items</h3>
                {userRole === 'staff' && (
                  <Button variant="outline" size="sm" onClick={handleAddItem}>
                    <Plus className="w-4 h-4 mr-1" />
                    Add Item
                  </Button>
                )}
              </div>

              {userRole === 'staff' && (
                <div className="grid grid-cols-4 gap-2 mb-4 p-3 bg-gray-50 rounded">
                  <Input
                    placeholder="Item type"
                    value={newItem.type}
                    onChange={(e) => setNewItem({ ...newItem, type: e.target.value })}
                  />
                  <Input
                    type="number"
                    placeholder="Qty"
                    value={newItem.quantity}
                    onChange={(e) => setNewItem({ ...newItem, quantity: parseInt(e.target.value) || 0 })}
                  />
                  <Input
                    type="number"
                    placeholder="Price"
                    value={newItem.price}
                    onChange={(e) => setNewItem({ ...newItem, price: parseFloat(e.target.value) || 0 })}
                  />
                  <Button onClick={handleAddItem}>Add</Button>
                </div>
              )}

              <div className="space-y-2">
                {items.map((item) => (
                  <div key={item.id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                    <div className="flex-1">
                      <p className="font-medium">{item.type}</p>
                      <p className="text-sm text-gray-600">
                        Quantity: {item.quantity} × ${item.price} = ${(item.quantity * item.price).toFixed(2)}
                      </p>
                    </div>
                    {userRole === 'staff' && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveItem(item.id)}
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>

              <div className="mt-4 p-4 bg-blue-50 rounded-lg flex justify-between items-center">
                <span className="font-semibold">Total Amount</span>
                <span className="text-2xl font-bold text-blue-600">${order.total.toFixed(2)}</span>
              </div>
            </div>

            <Button onClick={generatePDF} variant="outline" className="w-full">
              <Download className="w-4 h-4 mr-2" />
              Download Invoice (PDF)
            </Button>

            {order.rating && (
              <div className="p-4 bg-yellow-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  <span className="font-semibold">Customer Rating: {order.rating}/5</span>
                </div>
                {order.feedback && (
                  <p className="text-sm text-gray-700">{order.feedback}</p>
                )}
              </div>
            )}
          </TabsContent>

          <TabsContent value="status" className="space-y-4">
            {/* Status Timeline */}
            <div className="space-y-3">
              {statusFlow.map((status, idx) => {
                const isCompleted = statusFlow.indexOf(order.status) >= idx;
                const isCurrent = order.status === status;
                
                return (
                  <div key={status} className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      isCompleted ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-400'
                    }`}>
                      {idx + 1}
                    </div>
                    <div className="flex-1">
                      <p className={`font-medium ${isCurrent ? 'text-blue-600' : ''}`}>
                        {status.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}
                      </p>
                    </div>
                    {isCurrent && canUpdateStatus(statusFlow[idx + 1]) && 
                      (userRole === 'staff' || userRole === 'delivery' || userRole === 'admin') && (
                      <Button
                        size="sm"
                        onClick={() => handleStatusUpdate(statusFlow[idx + 1])}
                      >
                        Move to Next
                      </Button>
                    )}
                  </div>
                );
              })}
            </div>

            <Separator />

            {/* Assign Delivery Person (Staff/Admin only) */}
            {(userRole === 'staff' || userRole === 'admin') && order.status === 'ready' && (
              <div className="space-y-3">
                <Label>Assign Delivery Person</Label>
                <div className="flex gap-2">
                  <Select value={selectedDelivery} onValueChange={setSelectedDelivery}>
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder="Select delivery person" />
                    </SelectTrigger>
                    <SelectContent>
                      {deliveryPersons.map(person => (
                        <SelectItem key={person.id} value={person.id}>
                          {person.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button onClick={handleAssignDelivery}>Assign</Button>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="payment" className="space-y-4">
            {!order.paid ? (
              userRole === 'customer' ? (
                <div className="space-y-4">
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <p className="font-semibold mb-2">Payment Required</p>
                    <p className="text-2xl font-bold text-blue-600">${order.total.toFixed(2)}</p>
                  </div>

                  <div className="space-y-3">
                    <Label>Payment Method</Label>
                    <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="online">Online Payment</SelectItem>
                        <SelectItem value="card">Credit Card</SelectItem>
                        <SelectItem value="cash">Cash on Delivery</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button onClick={handlePayment} className="w-full">
                    Pay Now (Demo)
                  </Button>

                  <p className="text-xs text-gray-500 text-center">
                    This is a demo payment. No actual transaction will occur.
                  </p>
                </div>
              ) : (
                <div className="text-center py-8">
                  <DollarSign className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">Payment pending from customer</p>
                </div>
              )
            ) : (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <DollarSign className="w-8 h-8 text-green-600" />
                </div>
                <p className="text-lg font-semibold text-green-600">Payment Completed</p>
                <p className="text-sm text-gray-500 mt-2">Method: {order.paymentMethod}</p>
              </div>
            )}

            {/* Rating (Customer only, after delivery) */}
            {userRole === 'customer' && order.status === 'delivered' && !order.rating && (
              <div className="space-y-4 mt-6 p-4 border-t">
                <h3 className="font-semibold">Rate Your Experience</h3>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      onClick={() => setRating(star)}
                      className="focus:outline-none"
                    >
                      <Star
                        className={`w-8 h-8 ${
                          star <= rating
                            ? 'fill-yellow-400 text-yellow-400'
                            : 'text-gray-300'
                        }`}
                      />
                    </button>
                  ))}
                </div>
                <Textarea
                  placeholder="Share your feedback (optional)"
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value)}
                  rows={3}
                />
                <Button onClick={handleRating} className="w-full">
                  Submit Rating
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="chat">
            <ChatComponent orderId={order.id} />
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};

export default OrderDetailsModal;
