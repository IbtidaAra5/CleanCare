import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// Types
export type UserRole = 'admin' | 'staff' | 'delivery' | 'customer';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  address?: string;
  storeId?: string;
}

export interface LaundryStore {
  id: string;
  name: string;
  address: string;
  phone: string;
  createdAt: string;
}

export interface OrderItem {
  id: string;
  type: string;
  quantity: number;
  price: number;
}

export type OrderStatus = 
  | 'requested' 
  | 'picked_up' 
  | 'received' 
  | 'washing' 
  | 'ironing' 
  | 'ready' 
  | 'out_for_delivery' 
  | 'delivered';

export type ServiceType = 'wash' | 'wash_iron' | 'dry_clean';

export interface Order {
  id: string;
  customerId: string;
  customerName: string;
  storeId: string;
  storeName: string;
  deliveryPersonId?: string;
  deliveryPersonName?: string;
  status: OrderStatus;
  serviceType: ServiceType;
  pickupAddress: string;
  pickupTime: string;
  items: OrderItem[];
  total: number;
  paid: boolean;
  paymentMethod?: string;
  rating?: number;
  feedback?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ChatMessage {
  id: string;
  orderId: string;
  senderId: string;
  senderName: string;
  senderRole: UserRole;
  message: string;
  timestamp: string;
}

interface AppContextType {
  currentUser: User | null;
  users: User[];
  stores: LaundryStore[];
  orders: Order[];
  chatMessages: ChatMessage[];
  login: (email: string, password: string) => boolean;
  logout: () => void;
  register: (user: Omit<User, 'id'>) => boolean;
  addStore: (store: Omit<LaundryStore, 'id' | 'createdAt'>) => void;
  addStaff: (staff: Omit<User, 'id'>) => void;
  addDeliveryPerson: (person: Omit<User, 'id'>) => void;
  createOrder: (order: Omit<Order, 'id' | 'createdAt' | 'updatedAt'>) => string;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;
  updateOrderItems: (orderId: string, items: OrderItem[]) => void;
  assignDelivery: (orderId: string, deliveryPersonId: string, deliveryPersonName: string) => void;
  rateOrder: (orderId: string, rating: number, feedback: string) => void;
  payOrder: (orderId: string, paymentMethod: string) => void;
  sendMessage: (message: Omit<ChatMessage, 'id' | 'timestamp'>) => void;
  getOrderMessages: (orderId: string) => ChatMessage[];
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Initialize with mock data
const initializeData = () => {
  const storedData = localStorage.getItem('laundryAppData');
  
  if (storedData) {
    return JSON.parse(storedData);
  }

  // Default mock data
  const defaultStores: LaundryStore[] = [
    {
      id: 'store1',
      name: 'Downtown Laundry Center',
      address: '123 Main St, City Center',
      phone: '+1234567890',
      createdAt: '2024-01-01T10:00:00Z'
    },
    {
      id: 'store2',
      name: 'Eastside Fresh Cleaners',
      address: '456 East Ave, Eastside',
      phone: '+1234567891',
      createdAt: '2024-01-15T10:00:00Z'
    }
  ];

  const defaultUsers: User[] = [
    {
      id: 'admin1',
      name: 'Admin User',
      email: 'admin@laundry.com',
      role: 'admin'
    },
    {
      id: 'staff1',
      name: 'John Staff',
      email: 'staff@laundry.com',
      role: 'staff',
      storeId: 'store1'
    },
    {
      id: 'delivery1',
      name: 'Mike Driver',
      email: 'delivery@laundry.com',
      role: 'delivery',
      phone: '+1234567892'
    },
    {
      id: 'customer1',
      name: 'Sarah Customer',
      email: 'customer@laundry.com',
      role: 'customer',
      phone: '+1234567893',
      address: '789 Customer Lane'
    }
  ];

  const defaultOrders: Order[] = [
    {
      id: 'order1',
      customerId: 'customer1',
      customerName: 'Sarah Customer',
      storeId: 'store1',
      storeName: 'Downtown Laundry Center',
      deliveryPersonId: 'delivery1',
      deliveryPersonName: 'Mike Driver',
      status: 'washing',
      serviceType: 'wash_iron',
      pickupAddress: '789 Customer Lane',
      pickupTime: '2026-03-02T14:00:00Z',
      items: [
        { id: 'item1', type: 'Shirt', quantity: 5, price: 3 },
        { id: 'item2', type: 'Pants', quantity: 3, price: 5 }
      ],
      total: 30,
      paid: true,
      paymentMethod: 'online',
      createdAt: '2026-03-01T10:00:00Z',
      updatedAt: '2026-03-02T09:00:00Z'
    }
  ];

  return {
    users: defaultUsers,
    stores: defaultStores,
    orders: defaultOrders,
    chatMessages: []
  };
};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const storedUser = localStorage.getItem('currentUser');
    return storedUser ? JSON.parse(storedUser) : null;
  });

  const [data, setData] = useState(initializeData);

  // Save to localStorage whenever data changes
  useEffect(() => {
    localStorage.setItem('laundryAppData', JSON.stringify(data));
  }, [data]);

  const login = (email: string, password: string): boolean => {
    // Simple mock authentication (password is ignored for demo)
    const user = data.users.find(u => u.email === email);
    if (user) {
      setCurrentUser(user);
      localStorage.setItem('currentUser', JSON.stringify(user));
      return true;
    }
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
  };

  const register = (userData: Omit<User, 'id'>): boolean => {
    const exists = data.users.some(u => u.email === userData.email);
    if (exists) return false;

    const newUser: User = {
      ...userData,
      id: `user_${Date.now()}`
    };

    setData(prev => ({
      ...prev,
      users: [...prev.users, newUser]
    }));

    return true;
  };

  const addStore = (storeData: Omit<LaundryStore, 'id' | 'createdAt'>) => {
    const newStore: LaundryStore = {
      ...storeData,
      id: `store_${Date.now()}`,
      createdAt: new Date().toISOString()
    };

    setData(prev => ({
      ...prev,
      stores: [...prev.stores, newStore]
    }));
  };

  const addStaff = (staffData: Omit<User, 'id'>) => {
    const newStaff: User = {
      ...staffData,
      id: `staff_${Date.now()}`,
      role: 'staff'
    };

    setData(prev => ({
      ...prev,
      users: [...prev.users, newStaff]
    }));
  };

  const addDeliveryPerson = (personData: Omit<User, 'id'>) => {
    const newPerson: User = {
      ...personData,
      id: `delivery_${Date.now()}`,
      role: 'delivery'
    };

    setData(prev => ({
      ...prev,
      users: [...prev.users, newPerson]
    }));
  };

  const createOrder = (orderData: Omit<Order, 'id' | 'createdAt' | 'updatedAt'>): string => {
    const newOrder: Order = {
      ...orderData,
      id: `order_${Date.now()}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    setData(prev => ({
      ...prev,
      orders: [...prev.orders, newOrder]
    }));

    return newOrder.id;
  };

  const updateOrderStatus = (orderId: string, status: OrderStatus) => {
    setData(prev => ({
      ...prev,
      orders: prev.orders.map(order =>
        order.id === orderId
          ? { ...order, status, updatedAt: new Date().toISOString() }
          : order
      )
    }));
  };

  const updateOrderItems = (orderId: string, items: OrderItem[]) => {
    const total = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    setData(prev => ({
      ...prev,
      orders: prev.orders.map(order =>
        order.id === orderId
          ? { ...order, items, total, updatedAt: new Date().toISOString() }
          : order
      )
    }));
  };

  const assignDelivery = (orderId: string, deliveryPersonId: string, deliveryPersonName: string) => {
    setData(prev => ({
      ...prev,
      orders: prev.orders.map(order =>
        order.id === orderId
          ? { ...order, deliveryPersonId, deliveryPersonName, updatedAt: new Date().toISOString() }
          : order
      )
    }));
  };

  const rateOrder = (orderId: string, rating: number, feedback: string) => {
    setData(prev => ({
      ...prev,
      orders: prev.orders.map(order =>
        order.id === orderId
          ? { ...order, rating, feedback, updatedAt: new Date().toISOString() }
          : order
      )
    }));
  };

  const payOrder = (orderId: string, paymentMethod: string) => {
    setData(prev => ({
      ...prev,
      orders: prev.orders.map(order =>
        order.id === orderId
          ? { ...order, paid: true, paymentMethod, updatedAt: new Date().toISOString() }
          : order
      )
    }));
  };

  const sendMessage = (messageData: Omit<ChatMessage, 'id' | 'timestamp'>) => {
    const newMessage: ChatMessage = {
      ...messageData,
      id: `msg_${Date.now()}`,
      timestamp: new Date().toISOString()
    };

    setData(prev => ({
      ...prev,
      chatMessages: [...prev.chatMessages, newMessage]
    }));
  };

  const getOrderMessages = (orderId: string): ChatMessage[] => {
    return data.chatMessages.filter(msg => msg.orderId === orderId);
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        users: data.users,
        stores: data.stores,
        orders: data.orders,
        chatMessages: data.chatMessages,
        login,
        logout,
        register,
        addStore,
        addStaff,
        addDeliveryPerson,
        createOrder,
        updateOrderStatus,
        updateOrderItems,
        assignDelivery,
        rateOrder,
        payOrder,
        sendMessage,
        getOrderMessages
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};
