import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Badge } from '../components/ui/badge';
import { Package, Clock, CheckCircle } from 'lucide-react';
import DashboardLayout from '../components/DashboardLayout';
import OrdersTable from '../components/OrdersTable';
import OrderDetailsModal from '../components/OrderDetailsModal';
import { Order } from '../context/AppContext';

const StaffDashboard: React.FC = () => {
  const { orders, currentUser, stores } = useApp();
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  // Filter orders for the staff's store
  const userStore = stores.find(s => s.id === currentUser?.storeId);
  const storeOrders = orders.filter(order => order.storeId === currentUser?.storeId);

  const newOrders = storeOrders.filter(o => o.status === 'requested' || o.status === 'picked_up');
  const processingOrders = storeOrders.filter(o => 
    o.status === 'received' || o.status === 'washing' || o.status === 'ironing'
  );
  const readyOrders = storeOrders.filter(o => o.status === 'ready');

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Staff Dashboard</h1>
          <p className="text-gray-500">
            {userStore?.name || 'Laundry Store Management'}
          </p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">New Orders</CardTitle>
              <Package className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{newOrders.length}</div>
              <p className="text-xs text-gray-500">Awaiting processing</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">In Process</CardTitle>
              <Clock className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{processingOrders.length}</div>
              <p className="text-xs text-gray-500">Being processed</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Ready</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{readyOrders.length}</div>
              <p className="text-xs text-gray-500">Ready for delivery</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="new" className="space-y-4">
          <TabsList>
            <TabsTrigger value="new">
              New Orders
              {newOrders.length > 0 && (
                <Badge variant="secondary" className="ml-2">{newOrders.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="processing">
              In Process
              {processingOrders.length > 0 && (
                <Badge variant="secondary" className="ml-2">{processingOrders.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="ready">
              Ready
              {readyOrders.length > 0 && (
                <Badge variant="secondary" className="ml-2">{readyOrders.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="all">All Orders</TabsTrigger>
          </TabsList>

          <TabsContent value="new">
            <Card>
              <CardHeader>
                <CardTitle>New Orders</CardTitle>
                <CardDescription>Orders waiting to be received and processed</CardDescription>
              </CardHeader>
              <CardContent>
                {newOrders.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No new orders</p>
                ) : (
                  <OrdersTable 
                    orders={newOrders} 
                    onOrderClick={setSelectedOrder}
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="processing">
            <Card>
              <CardHeader>
                <CardTitle>Processing Orders</CardTitle>
                <CardDescription>Orders currently being washed, ironed, or prepared</CardDescription>
              </CardHeader>
              <CardContent>
                {processingOrders.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No orders in process</p>
                ) : (
                  <OrdersTable 
                    orders={processingOrders} 
                    onOrderClick={setSelectedOrder}
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ready">
            <Card>
              <CardHeader>
                <CardTitle>Ready Orders</CardTitle>
                <CardDescription>Orders ready for pickup or delivery</CardDescription>
              </CardHeader>
              <CardContent>
                {readyOrders.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No ready orders</p>
                ) : (
                  <OrdersTable 
                    orders={readyOrders} 
                    onOrderClick={setSelectedOrder}
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="all">
            <Card>
              <CardHeader>
                <CardTitle>All Orders</CardTitle>
                <CardDescription>Complete order history for this store</CardDescription>
              </CardHeader>
              <CardContent>
                <OrdersTable 
                  orders={storeOrders} 
                  showAll 
                  onOrderClick={setSelectedOrder}
                />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {selectedOrder && (
        <OrderDetailsModal
          order={selectedOrder}
          onClose={() => setSelectedOrder(null)}
          userRole="staff"
        />
      )}
    </DashboardLayout>
  );
};

export default StaffDashboard;
