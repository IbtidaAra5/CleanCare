import React from 'react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Shirt, Clock, Sparkles, MapPin, Phone, Mail, CheckCircle, Star, Truck, Shield, Zap, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

const Landing: React.FC = () => {
  const navigate = useNavigate();

  const priceList = [
    { item: 'Shirt', price: '$3', icon: Shirt },
    { item: 'Pants', price: '$5', icon: Shirt },
    { item: 'Dress', price: '$8', icon: Shirt },
    { item: 'Bedsheet', price: '$10', icon: Shirt },
    { item: 'Blanket', price: '$15', icon: Shirt },
    { item: 'Suit', price: '$20', icon: Shirt }
  ];

  const services = [
    {
      title: 'Wash Only',
      description: 'Basic washing service for your everyday laundry',
      icon: Shirt,
      color: 'from-blue-500 to-blue-600',
      features: ['Quick turnaround', 'Eco-friendly detergent', 'Quality assured']
    },
    {
      title: 'Wash & Iron',
      description: 'Complete service with professional ironing',
      icon: Sparkles,
      color: 'from-purple-500 to-purple-600',
      features: ['Perfect creases', 'Wrinkle-free', 'Ready to wear']
    },
    {
      title: 'Dry Clean',
      description: 'Premium dry cleaning for delicate garments',
      icon: Clock,
      color: 'from-pink-500 to-pink-600',
      features: ['Delicate care', 'Premium treatment', 'Stain removal']
    }
  ];

  const howItWorks = [
    { text: 'Create an account and place your order', icon: CheckCircle },
    { text: 'Choose pickup time and service type', icon: Clock },
    { text: 'Our delivery person collects your laundry', icon: Truck },
    { text: 'We process your items with care', icon: Sparkles },
    { text: 'Get fresh, clean clothes delivered back', icon: CheckCircle }
  ];

  const features = [
    { icon: Truck, title: 'Free Pickup & Delivery', description: 'At your doorstep' },
    { icon: Clock, title: '24-48 Hour Service', description: 'Quick turnaround' },
    { icon: Shield, title: 'Quality Guaranteed', description: '100% satisfaction' },
    { icon: Star, title: 'Expert Care', description: 'Professional staff' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-lg shadow-sm sticky top-0 z-50 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-3"
          >
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              CleanCare
            </span>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex gap-3"
          >
            <Button variant="outline" onClick={() => navigate('/login')} className="border-2 hover:border-blue-600 hover:text-blue-600 transition-all">
              Login
            </Button>
            <Button onClick={() => navigate('/register')} className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg hover:shadow-xl transition-all">
              Get Started
            </Button>
          </motion.div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-100/50 via-purple-100/30 to-pink-100/50" />
        <div className="max-w-7xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <Badge className="mb-6 px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 border-0">
              <Star className="w-4 h-4 mr-2" />
              Premium Laundry Service
            </Badge>
            <h1 className="text-6xl font-bold text-gray-900 mb-6 leading-tight">
              Premium Laundry Service
              <br />
              <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                at Your Doorstep
              </span>
            </h1>
            <p className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto leading-relaxed">
              Experience hassle-free laundry with professional care. We pick up, clean, and deliver 
              your clothes with exceptional quality and convenience.
            </p>
            <Button 
              size="lg" 
              onClick={() => navigate('/register')} 
              className="text-lg px-10 py-7 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-2xl hover:shadow-3xl transform hover:scale-105 transition-all"
            >
              Book Your First Pickup
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </motion.div>

          {/* Feature Pills */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto"
          >
            {features.map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={idx}
                  whileHover={{ scale: 1.05 }}
                  className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-gray-100"
                >
                  <Icon className="w-8 h-8 text-blue-600 mb-3 mx-auto" />
                  <h3 className="font-bold text-gray-900 mb-1">{feature.title}</h3>
                  <p className="text-sm text-gray-600">{feature.description}</p>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </section>

      {/* Services */}
      <section className="py-20 px-4 relative">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Premium Services</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Choose from our range of professional laundry services tailored to your needs
            </p>
          </motion.div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service, idx) => {
              const Icon = service.icon;
              return (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  whileHover={{ y: -10 }}
                >
                  <Card className="h-full border-0 shadow-xl hover:shadow-2xl transition-all overflow-hidden group">
                    <div className={`h-2 bg-gradient-to-r ${service.color}`} />
                    <CardHeader className="pb-4">
                      <div className={`w-16 h-16 bg-gradient-to-br ${service.color} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      <CardTitle className="text-2xl">{service.title}</CardTitle>
                      <CardDescription className="text-base">{service.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-3">
                        {service.features.map((feature, fIdx) => (
                          <li key={fIdx} className="flex items-center gap-2 text-gray-700">
                            <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-4 bg-gradient-to-br from-blue-50 to-indigo-50">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-xl text-gray-600">Simple steps to fresh, clean laundry</p>
          </motion.div>
          
          <div className="max-w-4xl mx-auto">
            {howItWorks.map((step, idx) => {
              const Icon = step.icon;
              return (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="relative mb-8 last:mb-0"
                >
                  <div className="flex items-start gap-6 bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all group">
                    <div className="flex-shrink-0 relative">
                      <div className="w-14 h-14 bg-gradient-to-br from-blue-600 to-indigo-600 text-white rounded-2xl flex items-center justify-center font-bold text-xl shadow-lg group-hover:scale-110 transition-transform">
                        {idx + 1}
                      </div>
                      {idx < howItWorks.length - 1 && (
                        <div className="absolute left-1/2 top-full w-0.5 h-8 bg-gradient-to-b from-blue-600 to-indigo-600 transform -translate-x-1/2" />
                      )}
                    </div>
                    <div className="flex-1 pt-2">
                      <Icon className="w-6 h-6 text-blue-600 mb-2" />
                      <p className="text-lg text-gray-800 font-medium">{step.text}</p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Transparent Pricing</h2>
            <p className="text-xl text-gray-600">Affordable rates for premium quality</p>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <Card className="max-w-4xl mx-auto border-0 shadow-2xl overflow-hidden">
              <div className="h-2 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600" />
              <CardHeader className="bg-gradient-to-br from-white to-blue-50">
                <CardTitle className="text-2xl">Price List</CardTitle>
                <CardDescription className="text-base">Clear pricing for all items</CardDescription>
              </CardHeader>
              <CardContent className="p-8">
                <div className="grid md:grid-cols-3 gap-4">
                  {priceList.map((item, idx) => {
                    const Icon = item.icon;
                    return (
                      <motion.div
                        key={idx}
                        whileHover={{ scale: 1.05 }}
                        className="flex justify-between items-center p-4 bg-gradient-to-br from-gray-50 to-blue-50 rounded-xl border-2 border-transparent hover:border-blue-600 transition-all"
                      >
                        <div className="flex items-center gap-3">
                          <Icon className="w-5 h-5 text-blue-600" />
                          <span className="font-semibold text-gray-900">{item.item}</span>
                        </div>
                        <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                          {item.price}
                        </span>
                      </motion.div>
                    );
                  })}
                </div>
                <div className="mt-6 p-4 bg-blue-50 rounded-xl border-2 border-blue-200">
                  <p className="text-sm text-gray-700 text-center">
                    <Zap className="w-4 h-4 inline mr-2 text-blue-600" />
                    Prices may vary based on service type (wash, wash & iron, dry clean)
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      {/* Contact */}
      <section className="py-20 px-4 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Get in Touch</h2>
            <p className="text-xl text-gray-600">We're here to help you</p>
          </motion.div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {[
              { icon: MapPin, title: 'Address', info: '123 Main St, City Center', color: 'from-blue-500 to-blue-600' },
              { icon: Phone, title: 'Phone', info: '+1 (234) 567-890', color: 'from-purple-500 to-purple-600' },
              { icon: Mail, title: 'Email', info: 'info@cleancare.com', color: 'from-pink-500 to-pink-600' }
            ].map((contact, idx) => {
              const Icon = contact.icon;
              return (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  whileHover={{ y: -10 }}
                >
                  <Card className="text-center border-0 shadow-xl hover:shadow-2xl transition-all overflow-hidden group">
                    <div className={`h-1 bg-gradient-to-r ${contact.color}`} />
                    <CardHeader className="pb-4">
                      <div className={`w-16 h-16 bg-gradient-to-br ${contact.color} rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}>
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      <CardTitle className="text-xl">{contact.title}</CardTitle>
                      <CardDescription className="text-base font-medium text-gray-700">{contact.info}</CardDescription>
                    </CardHeader>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-600 text-white">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto text-center"
        >
          <h2 className="text-4xl font-bold mb-6">Ready to Experience Premium Laundry Care?</h2>
          <p className="text-xl mb-10 text-blue-100">
            Join thousands of satisfied customers who trust us with their laundry
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg"
              onClick={() => navigate('/register')}
              className="text-lg px-10 py-7 bg-white text-blue-600 hover:bg-gray-100 shadow-2xl hover:shadow-3xl transform hover:scale-105 transition-all"
            >
              Get Started Now
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <Button 
              size="lg"
              variant="outline"
              onClick={() => navigate('/login')}
              className="text-lg px-10 py-7 border-2 border-white text-white hover:bg-white hover:text-blue-600 transition-all"
            >
              Login to Account
            </Button>
          </div>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-3 mb-6 md:mb-0">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center">
                <Sparkles className="w-6 h-6" />
              </div>
              <span className="text-2xl font-bold">CleanCare</span>
            </div>
            <div className="flex flex-col items-center md:items-end">
              <p className="text-gray-400 mb-2">© 2026 CleanCare. All rights reserved.</p>
              <p className="text-sm text-gray-500">Premium Laundry Service</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;