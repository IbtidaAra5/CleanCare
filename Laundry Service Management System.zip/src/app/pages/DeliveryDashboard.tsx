import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Badge } from '../components/ui/badge';
import { Truck, MapPin, CheckCircle, Clock } from 'lucide-react';
import DashboardLayout from '../components/DashboardLayout';
import OrdersTable from '../components/OrdersTable';
import OrderDetailsModal from '../components/OrderDetailsModal';
import { Order } from '../context/AppContext';

const DeliveryDashboard: React.FC = () => {
  const { orders, currentUser } = useApp();
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  // Filter orders assigned to this delivery person
  const myOrders = orders.filter(order => order.deliveryPersonId === currentUser?.id);

  const pickupOrders = myOrders.filter(o => o.status === 'requested');
  const deliveryOrders = myOrders.filter(o => o.status === 'ready' || o.status === 'out_for_delivery');
  const completedOrders = myOrders.filter(o => o.status === 'delivered');

  // Get today's and this week's deliveries
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 7);

  const todayDeliveries = completedOrders.filter(o => {
    const orderDate = new Date(o.updatedAt);
    orderDate.setHours(0, 0, 0, 0);
    return orderDate.getTime() === today.getTime();
  });

  const weeklyDeliveries = completedOrders.filter(o => {
    const orderDate = new Date(o.updatedAt);
    return orderDate >= weekAgo;
  });

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Delivery Dashboard</h1>
          <p className="text-gray-500">Manage pickups and deliveries</p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Pickups</CardTitle>
              <MapPin className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{pickupOrders.length}</div>
              <p className="text-xs text-gray-500">To be collected</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Ready to Deliver</CardTitle>
              <Truck className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{deliveryOrders.length}</div>
              <p className="text-xs text-gray-500">Awaiting delivery</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Today's Deliveries</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{todayDeliveries.length}</div>
              <p className="text-xs text-gray-500">Completed today</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Weekly Total</CardTitle>
              <Clock className="h-4 w-4 text-purple-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{weeklyDeliveries.length}</div>
              <p className="text-xs text-gray-500">Last 7 days</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="pickups" className="space-y-4">
          <TabsList>
            <TabsTrigger value="pickups">
              Pickups
              {pickupOrders.length > 0 && (
                <Badge variant="secondary" className="ml-2">{pickupOrders.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="deliveries">
              Deliveries
              {deliveryOrders.length > 0 && (
                <Badge variant="secondary" className="ml-2">{deliveryOrders.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
          </TabsList>

          <TabsContent value="pickups">
            <Card>
              <CardHeader>
                <CardTitle>Pending Pickups</CardTitle>
                <CardDescription>Laundry items to be collected from customers</CardDescription>
              </CardHeader>
              <CardContent>
                {pickupOrders.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No pending pickups</p>
                ) : (
                  <OrdersTable 
                    orders={pickupOrders} 
                    onOrderClick={setSelectedOrder}
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="deliveries">
            <Card>
              <CardHeader>
                <CardTitle>Ready for Delivery</CardTitle>
                <CardDescription>Orders ready to be delivered to customers</CardDescription>
              </CardHeader>
              <CardContent>
                {deliveryOrders.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No pending deliveries</p>
                ) : (
                  <OrdersTable 
                    orders={deliveryOrders} 
                    onOrderClick={setSelectedOrder}
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history">
            <Card>
              <CardHeader>
                <CardTitle>Delivery History</CardTitle>
                <CardDescription>Your completed deliveries</CardDescription>
              </CardHeader>
              <CardContent>
                {completedOrders.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No completed deliveries</p>
                ) : (
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4 mb-4">
                      <div className="p-4 bg-blue-50 rounded-lg">
                        <p className="text-sm text-gray-600">Today's Completions</p>
                        <p className="text-2xl font-bold text-blue-600">{todayDeliveries.length}</p>
                      </div>
                      <div className="p-4 bg-green-50 rounded-lg">
                        <p className="text-sm text-gray-600">This Week</p>
                        <p className="text-2xl font-bold text-green-600">{weeklyDeliveries.length}</p>
                      </div>
                    </div>
                    <OrdersTable 
                      orders={completedOrders} 
                      showAll 
                      onOrderClick={setSelectedOrder}
                    />
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {selectedOrder && (
        <OrderDetailsModal
          order={selectedOrder}
          onClose={() => setSelectedOrder(null)}
          userRole="delivery"
        />
      )}
    </DashboardLayout>
  );
};

export default DeliveryDashboard;
