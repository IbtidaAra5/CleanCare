import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Building2, Users, Truck, Package, BarChart3, Plus } from 'lucide-react';
import { toast } from 'sonner';
import DashboardLayout from '../components/DashboardLayout';
import OrdersTable from '../components/OrdersTable';
import ReportsPanel from '../components/ReportsPanel';

const AdminDashboard: React.FC = () => {
  const { stores, users, orders, addStore, addStaff, addDeliveryPerson } = useApp();
  
  const [storeForm, setStoreForm] = useState({
    name: '',
    address: '',
    phone: ''
  });

  const [staffForm, setStaffForm] = useState({
    name: '',
    email: '',
    storeId: ''
  });

  const [deliveryForm, setDeliveryForm] = useState({
    name: '',
    email: '',
    phone: ''
  });

  const handleAddStore = (e: React.FormEvent) => {
    e.preventDefault();
    addStore(storeForm);
    toast.success('Store added successfully');
    setStoreForm({ name: '', address: '', phone: '' });
  };

  const handleAddStaff = (e: React.FormEvent) => {
    e.preventDefault();
    addStaff({
      ...staffForm,
      role: 'staff'
    });
    toast.success('Staff member added successfully');
    setStaffForm({ name: '', email: '', storeId: '' });
  };

  const handleAddDelivery = (e: React.FormEvent) => {
    e.preventDefault();
    addDeliveryPerson({
      ...deliveryForm,
      role: 'delivery'
    });
    toast.success('Delivery person added successfully');
    setDeliveryForm({ name: '', email: '', phone: '' });
  };

  const staffMembers = users.filter(u => u.role === 'staff');
  const deliveryPersons = users.filter(u => u.role === 'delivery');
  const customers = users.filter(u => u.role === 'customer');

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-gray-500">Manage your laundry service business</p>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Stores</CardTitle>
              <Building2 className="h-4 w-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stores.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Staff Members</CardTitle>
              <Users className="h-4 w-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{staffMembers.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Delivery Team</CardTitle>
              <Truck className="h-4 w-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{deliveryPersons.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
              <Package className="h-4 w-4 text-gray-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{orders.length}</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="orders" className="space-y-4">
          <TabsList>
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="stores">Stores</TabsTrigger>
            <TabsTrigger value="staff">Staff</TabsTrigger>
            <TabsTrigger value="delivery">Delivery Team</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          <TabsContent value="orders">
            <Card>
              <CardHeader>
                <CardTitle>All Orders</CardTitle>
                <CardDescription>View and manage all laundry orders</CardDescription>
              </CardHeader>
              <CardContent>
                <OrdersTable orders={orders} showAll />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="stores">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Laundry Stores</CardTitle>
                  <CardDescription>Manage your store locations</CardDescription>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Store
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add New Store</DialogTitle>
                      <DialogDescription>Create a new laundry store location</DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleAddStore} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="store-name">Store Name</Label>
                        <Input
                          id="store-name"
                          placeholder="Downtown Laundry"
                          value={storeForm.name}
                          onChange={(e) => setStoreForm({ ...storeForm, name: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="store-address">Address</Label>
                        <Input
                          id="store-address"
                          placeholder="123 Main St"
                          value={storeForm.address}
                          onChange={(e) => setStoreForm({ ...storeForm, address: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="store-phone">Phone</Label>
                        <Input
                          id="store-phone"
                          placeholder="+1234567890"
                          value={storeForm.phone}
                          onChange={(e) => setStoreForm({ ...storeForm, phone: e.target.value })}
                          required
                        />
                      </div>
                      <Button type="submit" className="w-full">Add Store</Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {stores.map(store => (
                    <div key={store.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <h3 className="font-semibold">{store.name}</h3>
                        <p className="text-sm text-gray-500">{store.address}</p>
                        <p className="text-sm text-gray-500">{store.phone}</p>
                      </div>
                      <Building2 className="w-8 h-8 text-gray-400" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="staff">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Staff Members</CardTitle>
                  <CardDescription>Manage laundry staff accounts</CardDescription>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Staff
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Staff Member</DialogTitle>
                      <DialogDescription>Create a new staff account</DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleAddStaff} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="staff-name">Full Name</Label>
                        <Input
                          id="staff-name"
                          placeholder="John Doe"
                          value={staffForm.name}
                          onChange={(e) => setStaffForm({ ...staffForm, name: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="staff-email">Email</Label>
                        <Input
                          id="staff-email"
                          type="email"
                          placeholder="staff@email.com"
                          value={staffForm.email}
                          onChange={(e) => setStaffForm({ ...staffForm, email: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="staff-store">Assign to Store</Label>
                        <Select
                          value={staffForm.storeId}
                          onValueChange={(value) => setStaffForm({ ...staffForm, storeId: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select store" />
                          </SelectTrigger>
                          <SelectContent>
                            {stores.map(store => (
                              <SelectItem key={store.id} value={store.id}>
                                {store.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <Button type="submit" className="w-full">Add Staff</Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {staffMembers.map(staff => {
                    const store = stores.find(s => s.id === staff.storeId);
                    return (
                      <div key={staff.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <h3 className="font-semibold">{staff.name}</h3>
                          <p className="text-sm text-gray-500">{staff.email}</p>
                          {store && <p className="text-sm text-blue-600">{store.name}</p>}
                        </div>
                        <Users className="w-8 h-8 text-gray-400" />
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="delivery">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Delivery Team</CardTitle>
                  <CardDescription>Manage delivery personnel</CardDescription>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Delivery Person
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Delivery Person</DialogTitle>
                      <DialogDescription>Create a new delivery account</DialogDescription>
                    </DialogHeader>
                    <form onSubmit={handleAddDelivery} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="delivery-name">Full Name</Label>
                        <Input
                          id="delivery-name"
                          placeholder="Mike Driver"
                          value={deliveryForm.name}
                          onChange={(e) => setDeliveryForm({ ...deliveryForm, name: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="delivery-email">Email</Label>
                        <Input
                          id="delivery-email"
                          type="email"
                          placeholder="delivery@email.com"
                          value={deliveryForm.email}
                          onChange={(e) => setDeliveryForm({ ...deliveryForm, email: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="delivery-phone">Phone</Label>
                        <Input
                          id="delivery-phone"
                          placeholder="+1234567890"
                          value={deliveryForm.phone}
                          onChange={(e) => setDeliveryForm({ ...deliveryForm, phone: e.target.value })}
                          required
                        />
                      </div>
                      <Button type="submit" className="w-full">Add Delivery Person</Button>
                    </form>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {deliveryPersons.map(person => (
                    <div key={person.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <h3 className="font-semibold">{person.name}</h3>
                        <p className="text-sm text-gray-500">{person.email}</p>
                        <p className="text-sm text-gray-500">{person.phone}</p>
                      </div>
                      <Truck className="w-8 h-8 text-gray-400" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reports">
            <ReportsPanel />
          </TabsContent>
        </Tabs>
      </div>
    </DashboardLayout>
  );
};

export default AdminDashboard;
