import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Sparkles, Shield, Zap } from 'lucide-react';
import { motion } from 'motion/react';
import { toast } from 'sonner';

const Auth: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, register } = useApp();
  
  const isRegister = location.pathname === '/register';
  
  const [loginForm, setLoginForm] = useState({
    email: '',
    password: ''
  });

  const [registerForm, setRegisterForm] = useState({
    name: '',
    email: '',
    password: '',
    phone: '',
    address: ''
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const success = login(loginForm.email, loginForm.password);
    
    if (success) {
      toast.success('Login successful!');
      navigate('/dashboard');
    } else {
      toast.error('Invalid credentials');
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    const success = register({
      name: registerForm.name,
      email: registerForm.email,
      role: 'customer',
      phone: registerForm.phone,
      address: registerForm.address
    });

    if (success) {
      toast.success('Registration successful! Please login.');
      navigate('/login');
    } else {
      toast.error('Email already exists');
    }
  };

  const handleDemoLogin = (email: string) => {
    login(email, 'demo');
    toast.success('Logged in with demo account');
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNIDQwIDAgTCAwIDAgMCA0MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJyZ2JhKDI1NSwyNTUsMjU1LDAuMDUpIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-20" />
      
      <div className="w-full max-w-5xl z-10 grid md:grid-cols-2 gap-8 items-center">
        {/* Left side - Branding */}
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          className="hidden md:block text-white"
        >
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-2xl flex items-center justify-center shadow-2xl">
                <Sparkles className="w-10 h-10" />
              </div>
              <span className="text-4xl font-bold">CleanCare</span>
            </div>
            
            <h2 className="text-3xl font-bold leading-tight">
              Premium Laundry Service
              <br />
              <span className="text-blue-300">At Your Fingertips</span>
            </h2>
            
            <p className="text-blue-200 text-lg">
              Experience seamless laundry management with our powerful platform. 
              From order placement to delivery tracking, everything in one place.
            </p>

            <div className="space-y-4 pt-6">
              {[
                { icon: Shield, text: 'Secure & Reliable Platform' },
                { icon: Zap, text: 'Fast & Efficient Service' },
                { icon: Sparkles, text: 'Premium Quality Care' }
              ].map((feature, idx) => {
                const Icon = feature.icon;
                return (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 + idx * 0.1 }}
                    className="flex items-center gap-3"
                  >
                    <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center backdrop-blur-sm">
                      <Icon className="w-5 h-5 text-blue-300" />
                    </div>
                    <span className="text-white/90">{feature.text}</span>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </motion.div>

        {/* Right side - Auth form */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          {/* Mobile branding */}
          <div className="md:hidden text-center mb-8 text-white">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center shadow-xl">
                <Sparkles className="w-7 h-7" />
              </div>
              <span className="text-3xl font-bold">CleanCare</span>
            </div>
            <p className="text-blue-200">Premium Laundry Service</p>
          </div>

          <Card className="border-0 shadow-2xl backdrop-blur-xl bg-white/95">
            <CardHeader className="space-y-1 pb-6">
              <CardTitle className="text-2xl">{isRegister ? 'Create Account' : 'Welcome Back'}</CardTitle>
              <CardDescription className="text-base">
                {isRegister 
                  ? 'Sign up to start using our laundry service' 
                  : 'Login to manage your laundry orders'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={isRegister ? 'register' : 'login'} className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-6">
                  <TabsTrigger value="login" onClick={() => navigate('/login')} className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-indigo-600">
                    Login
                  </TabsTrigger>
                  <TabsTrigger value="register" onClick={() => navigate('/register')} className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-indigo-600">
                    Register
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="login" className="space-y-4">
                  <form onSubmit={handleLogin} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="your@email.com"
                        value={loginForm.email}
                        onChange={(e) => setLoginForm({ ...loginForm, email: e.target.value })}
                        required
                        className="h-11"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="password">Password</Label>
                      <Input
                        id="password"
                        type="password"
                        placeholder="••••••••"
                        value={loginForm.password}
                        onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                        required
                        className="h-11"
                      />
                    </div>
                    <Button type="submit" className="w-full h-11 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                      Login
                    </Button>
                  </form>

                  <div className="relative my-6">
                    <div className="absolute inset-0 flex items-center">
                      <span className="w-full border-t" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-white px-2 text-gray-500">Or try demo accounts</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      className="text-xs hover:bg-gradient-to-r hover:from-purple-50 hover:to-blue-50 hover:border-blue-300"
                      onClick={() => handleDemoLogin('admin@laundry.com')}
                    >
                      Admin Demo
                    </Button>
                    <Button
                      variant="outline"
                      className="text-xs hover:bg-gradient-to-r hover:from-purple-50 hover:to-blue-50 hover:border-blue-300"
                      onClick={() => handleDemoLogin('staff@laundry.com')}
                    >
                      Staff Demo
                    </Button>
                    <Button
                      variant="outline"
                      className="text-xs hover:bg-gradient-to-r hover:from-purple-50 hover:to-blue-50 hover:border-blue-300"
                      onClick={() => handleDemoLogin('delivery@laundry.com')}
                    >
                      Delivery Demo
                    </Button>
                    <Button
                      variant="outline"
                      className="text-xs hover:bg-gradient-to-r hover:from-purple-50 hover:to-blue-50 hover:border-blue-300"
                      onClick={() => handleDemoLogin('customer@laundry.com')}
                    >
                      Customer Demo
                    </Button>
                  </div>
                </TabsContent>

                <TabsContent value="register" className="space-y-4">
                  <form onSubmit={handleRegister} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        placeholder="John Doe"
                        value={registerForm.name}
                        onChange={(e) => setRegisterForm({ ...registerForm, name: e.target.value })}
                        required
                        className="h-11"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="reg-email">Email</Label>
                      <Input
                        id="reg-email"
                        type="email"
                        placeholder="your@email.com"
                        value={registerForm.email}
                        onChange={(e) => setRegisterForm({ ...registerForm, email: e.target.value })}
                        required
                        className="h-11"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="reg-password">Password</Label>
                      <Input
                        id="reg-password"
                        type="password"
                        placeholder="••••••••"
                        value={registerForm.password}
                        onChange={(e) => setRegisterForm({ ...registerForm, password: e.target.value })}
                        required
                        className="h-11"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone</Label>
                        <Input
                          id="phone"
                          type="tel"
                          placeholder="+1234567890"
                          value={registerForm.phone}
                          onChange={(e) => setRegisterForm({ ...registerForm, phone: e.target.value })}
                          className="h-11"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="address">Address</Label>
                        <Input
                          id="address"
                          placeholder="123 Main St"
                          value={registerForm.address}
                          onChange={(e) => setRegisterForm({ ...registerForm, address: e.target.value })}
                          className="h-11"
                        />
                      </div>
                    </div>
                    <Button type="submit" className="w-full h-11 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                      Create Account
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>

              <div className="mt-6 text-center">
                <Button
                  variant="link"
                  onClick={() => navigate('/')}
                  className="text-sm text-gray-600 hover:text-blue-600"
                >
                  Back to Home
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default Auth;