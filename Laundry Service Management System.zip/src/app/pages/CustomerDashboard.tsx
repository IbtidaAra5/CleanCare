import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Badge } from '../components/ui/badge';
import { Package, Clock, CheckCircle, Plus } from 'lucide-react';
import DashboardLayout from '../components/DashboardLayout';
import OrdersTable from '../components/OrdersTable';
import OrderDetailsModal from '../components/OrderDetailsModal';
import CreateOrderModal from '../components/CreateOrderModal';
import { Order } from '../context/AppContext';

const CustomerDashboard: React.FC = () => {
  const { orders, currentUser } = useApp();
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showCreateOrder, setShowCreateOrder] = useState(false);

  // Filter orders for current customer
  const myOrders = orders.filter(order => order.customerId === currentUser?.id);

  const activeOrders = myOrders.filter(o => 
    o.status !== 'delivered' && o.status !== 'ready'
  );
  const readyOrders = myOrders.filter(o => o.status === 'ready');
  const completedOrders = myOrders.filter(o => o.status === 'delivered');

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold">My Orders</h1>
            <p className="text-gray-500">Track and manage your laundry orders</p>
          </div>
          <Button onClick={() => setShowCreateOrder(true)}>
            <Plus className="w-4 h-4 mr-2" />
            New Order
          </Button>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Orders</CardTitle>
              <Clock className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{activeOrders.length}</div>
              <p className="text-xs text-gray-500">In progress</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Ready</CardTitle>
              <CheckCircle className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{readyOrders.length}</div>
              <p className="text-xs text-gray-500">Ready for pickup</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
              <Package className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{myOrders.length}</div>
              <p className="text-xs text-gray-500">All time</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="active" className="space-y-4">
          <TabsList>
            <TabsTrigger value="active">
              Active
              {activeOrders.length > 0 && (
                <Badge variant="secondary" className="ml-2">{activeOrders.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="ready">
              Ready
              {readyOrders.length > 0 && (
                <Badge variant="secondary" className="ml-2">{readyOrders.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
            <TabsTrigger value="all">All Orders</TabsTrigger>
          </TabsList>

          <TabsContent value="active">
            <Card>
              <CardHeader>
                <CardTitle>Active Orders</CardTitle>
                <CardDescription>Orders currently being processed</CardDescription>
              </CardHeader>
              <CardContent>
                {activeOrders.length === 0 ? (
                  <div className="text-center py-12">
                    <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500 mb-4">No active orders</p>
                    <Button onClick={() => setShowCreateOrder(true)}>
                      Create Your First Order
                    </Button>
                  </div>
                ) : (
                  <OrdersTable 
                    orders={activeOrders} 
                    onOrderClick={setSelectedOrder}
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ready">
            <Card>
              <CardHeader>
                <CardTitle>Ready for Pickup</CardTitle>
                <CardDescription>Your laundry is ready!</CardDescription>
              </CardHeader>
              <CardContent>
                {readyOrders.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No orders ready yet</p>
                ) : (
                  <OrdersTable 
                    orders={readyOrders} 
                    onOrderClick={setSelectedOrder}
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="completed">
            <Card>
              <CardHeader>
                <CardTitle>Completed Orders</CardTitle>
                <CardDescription>Your order history</CardDescription>
              </CardHeader>
              <CardContent>
                {completedOrders.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No completed orders</p>
                ) : (
                  <OrdersTable 
                    orders={completedOrders} 
                    showAll 
                    onOrderClick={setSelectedOrder}
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="all">
            <Card>
              <CardHeader>
                <CardTitle>All Orders</CardTitle>
                <CardDescription>Complete order history</CardDescription>
              </CardHeader>
              <CardContent>
                {myOrders.length === 0 ? (
                  <div className="text-center py-12">
                    <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500 mb-4">No orders yet</p>
                    <Button onClick={() => setShowCreateOrder(true)}>
                      Create Your First Order
                    </Button>
                  </div>
                ) : (
                  <OrdersTable 
                    orders={myOrders} 
                    showAll 
                    onOrderClick={setSelectedOrder}
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {selectedOrder && (
        <OrderDetailsModal
          order={selectedOrder}
          onClose={() => setSelectedOrder(null)}
          userRole="customer"
        />
      )}

      {showCreateOrder && (
        <CreateOrderModal
          onClose={() => setShowCreateOrder(false)}
        />
      )}
    </DashboardLayout>
  );
};

export default CustomerDashboard;
