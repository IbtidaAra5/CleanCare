
  # Laundry Service Management System

  This is a code bundle for Laundry Service Management System. The original project is available at https://www.figma.com/design/M8MxarsdCCWodV1Auw95Hz/Laundry-Service-Management-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  